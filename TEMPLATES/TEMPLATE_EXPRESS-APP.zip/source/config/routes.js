const controllers = require('../controllers/index');
// const multer = require('multer');
const auth = require('./permissions');

// let upload = multer({dest: `./content/images`});

module.exports = (app) => {
    "use strict";
    app.get("/", controllers.home.homeGet);

    app.get('/user/register', controllers.user.registerGet);
    app.post('/user/register', controllers.user.registerPost);

    app.get('/user/login', controllers.user.loginGet);
    app.post('/user/login', controllers.user.loginPost);

    app.post('/user/logout', controllers.user.logout);

};