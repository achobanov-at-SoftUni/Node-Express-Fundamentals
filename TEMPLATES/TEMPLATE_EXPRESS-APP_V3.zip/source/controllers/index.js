const homeController = require('./home');
const userController = require('./user');

module.exports = {
    user: userController,
    home: homeController,
};