const homeHandler = require('./home');
const filesHandler = require('./content-files');
const pictureHandler = require('./picture');

module.exports = [ homeHandler, filesHandler, pictureHandler ];