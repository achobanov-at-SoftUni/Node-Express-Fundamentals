

function previousPage() {
    "use strict";
    window.history.back();
}